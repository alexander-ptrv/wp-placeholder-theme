<php 

wp_enqueue_style( 'style', get_stylesheet_uri() );
add_theme_support( 'custom-logo' );
